const BADGE_ALARM_NAME = "submit-tracker-badge-refresh";
const CHIME_ALARM_PREFIX = "submit-tracker-chime:";
const OPEN_TAB_PREFIX = "mangoOpenTab:";
const OFFSCREEN_URL = "offscreen.html";
const DEFAULT_CHIME_SETTINGS = {
  enabled: false,
  delaySeconds: 300,
  sound: "gentle"
};
let browserStartupAt = 0;

function formatBadge(ms) {
  if (!Number.isFinite(ms) || ms < 0) return "";
  const sec = Math.floor(ms / 1000);
  return `${Math.floor(sec / 60)}m`;
}

async function updateBadgeForActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const origin = tab?.url ? new URL(tab.url).origin : null;
  if (!origin) {
    await chrome.action.setBadgeText({ text: "" });
    return;
  }

  const key = `heartbeatClock:${origin}`;
  const data = (await chrome.storage.local.get([key]))[key];
  const path = new URL(tab.url).pathname.replace(/\/$/, "");
  const zeroRoute = new URL(tab.url).hostname === "www.multimango.com" &&
    ["/tasks", "/qa-feedback"].includes(path);
  const text = zeroRoute ? "0m" : Number.isFinite(data?.firstHeartbeatAt)
    ? formatBadge(Date.now() - data.firstHeartbeatAt)
    : data?.waitingAtZero ? "0m" : "";

  await chrome.action.setBadgeBackgroundColor({ color: "#2a7cff" });
  await chrome.action.setBadgeText({ text });
}

async function ensureBadgeAlarm() {
  const existing = await chrome.alarms.get(BADGE_ALARM_NAME);
  if (!existing) {
    await chrome.alarms.create(BADGE_ALARM_NAME, { periodInMinutes: 0.5 });
  }
}

function alarmNameForOrigin(origin) {
  return `${CHIME_ALARM_PREFIX}${encodeURIComponent(origin)}`;
}

function originFromAlarmName(name) {
  try {
    return decodeURIComponent(name.slice(CHIME_ALARM_PREFIX.length));
  } catch {
    return null;
  }
}

async function getChimeSettings() {
  const { chimeSettings } = await chrome.storage.sync.get(["chimeSettings"]);
  return { ...DEFAULT_CHIME_SETTINGS, ...chimeSettings };
}

async function consumeChime(clockKey, clock) {
  clock.chimedForHeartbeatAt = clock.firstHeartbeatAt;
  delete clock.chimeScheduledForHeartbeatAt;
  delete clock.chimeDueAt;
  await chrome.storage.local.set({ [clockKey]: clock });
}

async function scheduleChime(origin, { discardIfOverdue = false } = {}) {
  if (!origin) return;
  const clockKey = `heartbeatClock:${origin}`;
  const [settings, local] = await Promise.all([
    getChimeSettings(),
    chrome.storage.local.get([clockKey])
  ]);
  const clock = local[clockKey];
  const alarmName = alarmNameForOrigin(origin);
  await chrome.alarms.clear(alarmName);
  if (!settings.enabled || clock?.paused || !Number.isFinite(clock?.firstHeartbeatAt) ||
      clock.chimedForHeartbeatAt === clock.firstHeartbeatAt) return;

  const delaySeconds = Math.max(30, Number(settings.delaySeconds) || 300);
  const dueAt = clock.firstHeartbeatAt + delaySeconds * 1000;
  if (discardIfOverdue && dueAt <= Date.now()) {
    await consumeChime(clockKey, clock);
    return;
  }
  clock.chimeScheduledForHeartbeatAt = clock.firstHeartbeatAt;
  clock.chimeDueAt = dueAt;
  await chrome.storage.local.set({ [clockKey]: clock });
  await chrome.alarms.create(alarmName, { when: Math.max(Date.now() + 500, dueAt) });
}

async function stopTimerForOrigin(origin) {
  if (!origin) return;
  await chrome.alarms.clear(alarmNameForOrigin(origin));
  await updateBadgeForActiveTab();
}

async function hasOpenPageForOrigin(origin) {
  const tabs = await chrome.tabs.query({ url: `${origin}/*` });
  return tabs.length > 0;
}

async function resetClockIfPageGone(origin) {
  if (await hasOpenPageForOrigin(origin)) return false;
  const clockKey = `heartbeatClock:${origin}`;
  const previous = (await chrome.storage.local.get(clockKey))[clockKey];
  if (previous?.firstHeartbeatAt) {
    await chrome.storage.local.set({ [clockKey]: {
      taskId: previous.taskId || null,
      firstHeartbeatAt: null,
      limit: null,
      itemKey: null,
      resetAt: Date.now(),
      paused: false,
      waitingAtZero: true
    } });
  }
  await chrome.alarms.clear(alarmNameForOrigin(origin));
  return true;
}

async function checkDepartedClocks() {
  const allLocal = await chrome.storage.local.get(null);
  for (const [key, clock] of Object.entries(allLocal)) {
    if (key.startsWith("heartbeatClock:") && Number.isFinite(clock?.firstHeartbeatAt)) {
      await resetClockIfPageGone(key.slice("heartbeatClock:".length));
    }
  }
}

function supportedOrigin(origin) {
  try {
    const url = new URL(origin);
    return url.protocol === "https:" &&
      ["multimango.com", "parimango.com"].some(domain =>
        url.hostname === domain || url.hostname.endsWith(`.${domain}`));
  } catch { return false; }
}

async function rememberOpenTab(sender) {
  const origin = sender?.origin;
  if (!Number.isInteger(sender?.tab?.id) || !supportedOrigin(origin)) return;
  await chrome.storage.session.set({ [`${OPEN_TAB_PREFIX}${sender.tab.id}`]: origin });
}

async function forgetClosedTab(tabId) {
  const tabKey = `${OPEN_TAB_PREFIX}${tabId}`;
  const origin = (await chrome.storage.session.get(tabKey))[tabKey];
  if (!origin) return;
  await chrome.storage.session.remove(tabKey);
  const openTabs = await chrome.storage.session.get(null);
  if (Object.entries(openTabs).some(([key, value]) =>
    key.startsWith(OPEN_TAB_PREFIX) && value === origin)) return;

  const clockKey = `heartbeatClock:${origin}`;
  const previous = (await chrome.storage.local.get(clockKey))[clockKey];
  if (previous) {
    await chrome.storage.local.set({ [clockKey]: {
      taskId: previous.taskId || null,
      firstHeartbeatAt: null,
      limit: null,
      itemKey: null,
      resetAt: Date.now(),
      paused: false,
      waitingAtZero: true
    } });
  }
  await stopTimerForOrigin(origin);
}

async function reschedulePendingChimes({ discardOverdue = false } = {}) {
  const alarms = await chrome.alarms.getAll();
  for (const alarm of alarms) {
    if (alarm.name.startsWith(CHIME_ALARM_PREFIX)) await chrome.alarms.clear(alarm.name);
  }
  const allLocal = await chrome.storage.local.get(null);
  for (const [key, clock] of Object.entries(allLocal)) {
    if (key.startsWith("heartbeatClock:") &&
        !clock?.paused && Number.isFinite(clock?.firstHeartbeatAt) &&
        clock.chimedForHeartbeatAt !== clock.firstHeartbeatAt) {
      await scheduleChime(key.slice("heartbeatClock:".length), { discardIfOverdue: discardOverdue });
    }
  }
}

async function ensureAudioDocument() {
  if (!chrome.offscreen?.createDocument) return false;

  const hasDocument = await chrome.offscreen.hasDocument();
  if (!hasDocument) {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: [chrome.offscreen.Reason.AUDIO_PLAYBACK],
      justification: "Play the user-selected timer chime"
    });
  }
  return true;
}

async function playChime(sound) {
  if (sound === "silent") return;
  if (!(await ensureAudioDocument())) return;
  chrome.runtime.sendMessage({
    type: "submitTracker:playChime",
    sound: ["gentle", "clear", "strong"].includes(sound) ? sound : "gentle"
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  await ensureBadgeAlarm();
  await reschedulePendingChimes({ discardOverdue: true });
  await updateBadgeForActiveTab();
});

chrome.runtime.onStartup.addListener(async () => {
  browserStartupAt = Date.now();
  await ensureBadgeAlarm();
  await reschedulePendingChimes({ discardOverdue: true });
  await updateBadgeForActiveTab();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm?.name === BADGE_ALARM_NAME) {
    await updateBadgeForActiveTab();
    return;
  }

  if (!alarm?.name?.startsWith(CHIME_ALARM_PREFIX)) return;

  const origin = originFromAlarmName(alarm.name);
  if (!origin) return;
  if (await resetClockIfPageGone(origin)) return;

  const clockKey = `heartbeatClock:${origin}`;
  const [settings, local] = await Promise.all([
    getChimeSettings(),
    chrome.storage.local.get([clockKey])
  ]);
  const clock = local[clockKey];
  if (!settings.enabled || clock?.paused || !Number.isFinite(clock?.firstHeartbeatAt) ||
      clock.chimedForHeartbeatAt === clock.firstHeartbeatAt ||
      clock.chimeScheduledForHeartbeatAt !== clock.firstHeartbeatAt) return;

  // Do not play a stale reminder after a browser restart.
  if (browserStartupAt && clock.chimeDueAt && clock.chimeDueAt <= browserStartupAt) {
    await consumeChime(clockKey, clock);
    return;
  }
  await consumeChime(clockKey, clock);
  await playChime(settings.sound);
});

chrome.tabs.onActivated.addListener(() => updateBadgeForActiveTab());
chrome.tabs.onUpdated.addListener((_tabId, changeInfo) => {
  if (changeInfo.status === "complete") {
    updateBadgeForActiveTab();
    checkDepartedClocks();
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  forgetClosedTab(tabId);
});
chrome.windows.onFocusChanged.addListener(() => updateBadgeForActiveTab());

chrome.runtime.onMessage.addListener((msg, sender) => {
  rememberOpenTab(sender);
  if (msg?.type === "submitTracker:pressed") {
    updateBadgeForActiveTab();
  }

  if (msg?.type === "submitTracker:heartbeatClockStarted") {
    updateBadgeForActiveTab();
    scheduleChime(msg.origin);
  }

  if (msg?.type === "submitTracker:timerStopped") {
    stopTimerForOrigin(msg.origin);
  }

  if (msg?.type === "submitTracker:updateBadge") {
    updateBadgeForActiveTab();
  }

  if (msg?.type === "submitTracker:chimeSettingsChanged") {
    reschedulePendingChimes({ discardOverdue: true });
  }

  if (msg?.type === "submitTracker:previewChime") {
    playChime(msg.sound);
  }

});

ensureBadgeAlarm();
