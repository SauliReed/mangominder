const DEFAULT_LABELS = ["Submit"];

function normalizeLabel(s) {
  return (s || "").trim().replace(/\s+/g, " ").toLowerCase();
}

function getCandidateLabel(el) {
  // Priority: aria-label, value (input), then visible text.
  if (!el) return "";
  const aria = el.getAttribute?.("aria-label");
  if (aria) return aria;

  if (el.tagName === "INPUT") {
    const val = el.getAttribute("value");
    if (val) return val;
  }

  return el.innerText || el.textContent || "";
}

function isClickableButtonLike(el) {
  if (!el) return false;
  const tag = el.tagName;

  if (tag === "BUTTON") return true;
  if (tag === "INPUT") {
    const type = (el.getAttribute("type") || "").toLowerCase();
    return ["button", "submit", "image", "reset"].includes(type);
  }
  // Some sites use div/span with role=button
  const role = (el.getAttribute("role") || "").toLowerCase();
  if (role === "button") return true;

  return false;
}

function findButtonLike(startEl) {
  // Walk up to find a button-like element
  let el = startEl;
  while (el && el !== document.documentElement) {
    if (isClickableButtonLike(el)) return el;
    el = el.parentElement;
  }
  return null;
}

function originKeyFromLocation() {
  // Per-site persistence
  return location.origin;
}

async function getSettings() {
  const { trackedLabels } = await chrome.storage.sync.get(["trackedLabels"]);
  return {
    trackedLabels:
      Array.isArray(trackedLabels) && trackedLabels.length
        ? trackedLabels
        : DEFAULT_LABELS
  };
}

async function bumpCount() {
  const siteKey = originKeyFromLocation();
  const storageKey = `site:${siteKey}`;

  const now = Date.now();
  const existing = await chrome.storage.local.get([storageKey]);
  const data = existing[storageKey] || { count: 0, lastPressedAt: null };

  data.count = (data.count || 0) + 1;
  data.lastPressedAt = now;
  delete data.timerResetAtZero;

  await chrome.storage.local.set({ [storageKey]: data });
  // A Submit may open a dialog; keep elapsed time until the next item arrives.
  chrome.runtime.sendMessage({ type: "submitTracker:timerStopped", origin: siteKey });

  // Nudge the service worker to refresh the toolbar badge immediately.
  try {
    chrome.runtime.sendMessage({ type: "submitTracker:pressed", origin: siteKey });
  } catch {
    // ignore
  }
}

document.addEventListener(
  "click",
  async (evt) => {
    const btn = findButtonLike(evt.target);
    if (!btn) return;

    const label = normalizeLabel(getCandidateLabel(btn));
    if (!label) return;

    const { trackedLabels } = await getSettings();
    const normalizedTracked = trackedLabels.map(normalizeLabel);

    if (normalizedTracked.includes(label)) {
      bumpCount();
    }
  },
  true // capture helps catch some frameworks
);

// Floating timer overlay. A shadow root isolates it from the host page's CSS.
const TIMER_OVERLAY_ID = "submit-tracker-timer-overlay";
const TIMER_VISIBLE_KEY = `timerOverlayVisible:${location.origin}`;
const TIMER_POSITION_KEY = `timerOverlayPosition:${location.origin}`;
const HEARTBEAT_CLOCK_KEY = `heartbeatClock:${location.origin}`;
const ZERO_TIMER_PATHS = new Set(["/tasks", "/qa-feedback"]);
function isZeroTimerRoute() {
  return location.hostname === "www.multimango.com" &&
    ZERO_TIMER_PATHS.has(location.pathname.replace(/\/$/, ""));
}
// Remove an overlay left behind by an older extension build before creating
// the current timer-only panel.
document.getElementById(TIMER_OVERLAY_ID)?.remove();

let timerOverlayHost = null;
let timerOverlayHandle = null;
let heartbeatClock = null;
let heartbeatWrite = Promise.resolve();
let timerOverlayChimeEnabled = false;
let timerOverlayChimeDelaySeconds = 300;
let timerOverlayChimeSound = "gentle";
function formatOverlayDuration(ms) {
  if (!Number.isFinite(ms) || ms < 0) return "—";

  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours) {
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }

  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function renderTimerOverlay() {
  const shadow = timerOverlayHost?.shadowRoot;
  if (!shadow) return;

  const timer = shadow.getElementById("timer");
  if (isZeroTimerRoute()) {
    timer.textContent = "00:00";
    timer.classList.remove("chime-reached");
    return;
  }
  const startedAt = heartbeatClock?.firstHeartbeatAt;
  const elapsedMs = Number.isFinite(startedAt)
    ? Math.max(0, Date.now() - startedAt)
    : null;
  timer.textContent = elapsedMs !== null
    ? formatOverlayDuration(elapsedMs)
    : heartbeatClock?.waitingAtZero ? "00:00" : "—";
  timer.classList.toggle(
    "chime-reached",
    Boolean(
      timerOverlayChimeEnabled &&
      elapsedMs !== null &&
      elapsedMs >=
        Math.max(30, timerOverlayChimeDelaySeconds) * 1000
    )
  );
}

function renderNotificationStatusIcon() {
  const icon = timerOverlayHost?.shadowRoot?.getElementById("notificationStatus");
  if (!icon) return;

  const state = !timerOverlayChimeEnabled
    ? "off"
    : timerOverlayChimeSound === "silent"
      ? "silent"
      : "audible";
  const label = state === "off"
    ? "Notifications off"
    : state === "silent"
      ? "Silent notifications on"
      : "Audible notifications on";

  icon.dataset.state = state;
  icon.setAttribute("aria-label", label);
  icon.title = label;
}

async function refreshTimerOverlayData() {
  const [local, synced] = await Promise.all([
    chrome.storage.local.get([HEARTBEAT_CLOCK_KEY]),
    chrome.storage.sync.get(["chimeSettings"])
  ]);
  heartbeatClock = local[HEARTBEAT_CLOCK_KEY] || null;
  timerOverlayChimeEnabled = Boolean(synced.chimeSettings?.enabled);
  timerOverlayChimeDelaySeconds =
    Number(synced.chimeSettings?.delaySeconds) || 300;
  timerOverlayChimeSound = synced.chimeSettings?.sound || "gentle";
  renderTimerOverlay();
  renderNotificationStatusIcon();
}

function resetHeartbeatClock(paused = false, waitingAtZero = false) {
  heartbeatWrite = heartbeatWrite.then(async () => {
    const previous = (await chrome.storage.local.get(HEARTBEAT_CLOCK_KEY))[HEARTBEAT_CLOCK_KEY];
    const reset = { taskId: previous?.taskId || null, firstHeartbeatAt: null,
      limit: null, resetAt: Date.now(), paused, waitingAtZero };
    heartbeatClock = reset;
    await chrome.storage.local.set({ [HEARTBEAT_CLOCK_KEY]: reset });
    renderTimerOverlay();
  });
  return heartbeatWrite;
}

let lastZeroRoute = null;
function syncZeroTimerRoute() {
  const blocked = isZeroTimerRoute();
  if (blocked === lastZeroRoute) return;
  lastZeroRoute = blocked;
  if (blocked) {
    resetHeartbeatClock(true);
    chrome.runtime.sendMessage({ type: "submitTracker:timerStopped", origin: location.origin });
  } else {
    chrome.runtime.sendMessage({ type: "submitTracker:updateBadge" });
  }
  renderTimerOverlay();
}
syncZeroTimerRoute();
const navigation = performance.getEntriesByType?.("navigation")?.[0];
if (!isZeroTimerRoute() &&
    (navigation?.type === "reload" || (!navigation && performance.navigation?.type === 1))) {
  resetHeartbeatClock(false, true).then(() => {
    chrome.runtime.sendMessage({ type: "submitTracker:timerStopped", origin: location.origin });
  });
}
window.addEventListener("popstate", syncZeroTimerRoute);
setInterval(syncZeroTimerRoute, 500);

// Keep the badge in step with the popup's wall-clock display while this tab is active.
let lastBadgeSecond = -1;
function refreshBadgeSecond() {
  if (document.visibilityState !== "visible") return;
  const second = Math.floor(Date.now() / 1000);
  if (second === lastBadgeSecond) return;
  lastBadgeSecond = second;
  chrome.runtime.sendMessage({ type: "submitTracker:updateBadge" });
}
setInterval(refreshBadgeSecond, 250);
document.addEventListener("visibilitychange", refreshBadgeSecond);
refreshBadgeSecond();

window.addEventListener("message", (event) => {
  const data = event.data;
  if (event.source !== window || event.origin !== location.origin ||
      data?.channel !== "submitTracker:heartbeatClock" ||
      !Number.isFinite(data.observedAt)) return;
  syncZeroTimerRoute();
  if (isZeroTimerRoute()) return;

  if (data.type === "acquired") {
    if (typeof data.itemKey !== "string" || !/^\d+:\d+:\d+:\d+$/.test(data.itemKey)) return;
    heartbeatWrite = heartbeatWrite.then(async () => {
      if (isZeroTimerRoute()) return;
      const prior = (await chrome.storage.local.get(HEARTBEAT_CLOCK_KEY))[HEARTBEAT_CLOCK_KEY];
      if (prior?.itemKey === data.itemKey && Number.isFinite(prior.firstHeartbeatAt)) return;
      if (data.observedAt <= (prior?.resetAt || 0)) return;
      const clock = { taskId: null, itemKey: data.itemKey,
        firstHeartbeatAt: data.observedAt, limit: prior?.limit ?? null,
        resetAt: data.observedAt, paused: false, waitingAtZero: false };
      heartbeatClock = clock;
      await chrome.storage.local.set({ [HEARTBEAT_CLOCK_KEY]: clock });
      chrome.runtime.sendMessage({ type: "submitTracker:heartbeatClockStarted", origin: location.origin });
      renderTimerOverlay();
    });
    return;
  }

  if (data.type !== "success" || typeof data.taskId !== "string" || !data.taskId) return;

  heartbeatWrite = heartbeatWrite.then(async () => {
    if (isZeroTimerRoute()) return;
    const prior = (await chrome.storage.local.get(HEARTBEAT_CLOCK_KEY))[HEARTBEAT_CLOCK_KEY];
    if (data.observedAt <= (prior?.resetAt || 0)) return;
    const sameTask = prior?.taskId === data.taskId ||
      (prior?.taskId === null && Boolean(prior?.itemKey));
    const clock = {
      ...(sameTask ? prior : {}),
      taskId: data.taskId,
      firstHeartbeatAt: sameTask && Number.isFinite(prior.firstHeartbeatAt)
        ? prior.firstHeartbeatAt : data.observedAt,
      resetAt: prior?.resetAt || 0,
      paused: false,
      waitingAtZero: false,
      limit: Number.isFinite(data.limit) && data.limit > 0
        ? data.limit : sameTask ? prior?.limit || null : null
    };
    heartbeatClock = clock;
    await chrome.storage.local.set({ [HEARTBEAT_CLOCK_KEY]: clock });
    if (!sameTask || !Number.isFinite(prior?.firstHeartbeatAt)) {
      chrome.runtime.sendMessage({ type: "submitTracker:heartbeatClockStarted", origin: location.origin });
    }
    renderTimerOverlay();
  });
});

function enableTimerOverlayDragging(panel, handle) {
  let drag = null;

  handle.addEventListener("pointerdown", (event) => {
    const rect = panel.getBoundingClientRect();
    drag = {
      pointerId: event.pointerId,
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top
    };
    handle.setPointerCapture(event.pointerId);
  });

  handle.addEventListener("pointermove", (event) => {
    if (!drag || event.pointerId !== drag.pointerId) return;

    const maxLeft = Math.max(8, window.innerWidth - panel.offsetWidth - 8);
    const maxTop = Math.max(8, window.innerHeight - panel.offsetHeight - 8);
    const left = Math.min(maxLeft, Math.max(8, event.clientX - drag.offsetX));
    const top = Math.min(maxTop, Math.max(8, event.clientY - drag.offsetY));

    panel.style.right = "auto";
    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
  });

  const finishDrag = async (event) => {
    if (!drag || event.pointerId !== drag.pointerId) return;
    drag = null;
    handle.releasePointerCapture(event.pointerId);

    const rect = panel.getBoundingClientRect();
    await chrome.storage.local.set({
      [TIMER_POSITION_KEY]: {
        left: Math.round(rect.left),
        top: Math.round(rect.top)
      }
    });
  };

  handle.addEventListener("pointerup", finishDrag);
  handle.addEventListener("pointercancel", finishDrag);
}

async function showTimerOverlay() {
  if (timerOverlayHost) return;

  const host = document.createElement("div");
  host.id = TIMER_OVERLAY_ID;
  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `
    :host {
      all: initial;
    }

    .panel {
      position: fixed;
      z-index: 2147483647;
      top: 16px;
      right: 16px;
      width: 184px;
      overflow: hidden;
      color: #f7f9fc;
      background: #192231;
      border: 1px solid #657083;
      border-radius: 16px;
      box-shadow: 0 14px 34px rgb(0 0 0 / 28%);
      cursor: move;
      font-family: system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
      touch-action: none;
      user-select: none;
    }

    .timer {
      display: grid;
      min-height: 78px;
      padding: 12px;
      box-sizing: border-box;
      place-items: center;
      color: #f8f9fd;
      font-size: 40px;
      font-variant-numeric: tabular-nums;
      font-weight: 780;
      letter-spacing: -0.035em;
      line-height: 1;
      text-align: center;
      text-shadow: 0 0 16px rgb(42 124 255 / 18%);
      white-space: nowrap;
      transition: color 160ms ease, text-shadow 160ms ease;
    }

    .timer.chime-reached {
      color: #ef4444;
      text-shadow: 0 0 16px rgb(239 68 68 / 42%);
    }

    .notification-status {
      position: absolute;
      z-index: 3;
      top: 8px;
      right: 8px;
      display: grid;
      width: 24px;
      height: 24px;
      box-sizing: border-box;
      place-items: center;
      color: #ef4444;
      background: transparent;
      border: 0;
      filter: drop-shadow(0 0 4px currentColor);
      opacity: 1;
      visibility: visible;
      pointer-events: none;
    }

    .notification-status[data-state="audible"] {
      color: #22c55e;
    }

    .notification-status[data-state="silent"] {
      color: #f59e0b;
    }

    .notification-status svg {
      display: block;
      width: 17px;
      height: 17px;
      fill: none;
      stroke: currentColor;
      stroke-linecap: round;
      stroke-linejoin: round;
      stroke-width: 2;
    }

    .notification-status[data-state="audible"] .slash {
      display: none;
    }

  `;

  const panel = document.createElement("section");
  panel.className = "panel";
  panel.setAttribute("aria-label", "Elapsed task timer");

  const timer = document.createElement("time");
  timer.id = "timer";
  timer.className = "timer";
  timer.textContent = "—";

  const notificationStatus = document.createElement("span");
  notificationStatus.id = "notificationStatus";
  notificationStatus.className = "notification-status";
  notificationStatus.dataset.state = "off";

  const svgNamespace = "http://www.w3.org/2000/svg";
  const bell = document.createElementNS(svgNamespace, "svg");
  bell.setAttribute("viewBox", "0 0 24 24");
  bell.setAttribute("width", "17");
  bell.setAttribute("height", "17");
  bell.setAttribute("fill", "none");
  bell.setAttribute("stroke", "currentColor");
  bell.setAttribute("stroke-width", "2");
  bell.setAttribute("stroke-linecap", "round");
  bell.setAttribute("stroke-linejoin", "round");
  bell.setAttribute("aria-hidden", "true");

  const bellShape = document.createElementNS(svgNamespace, "path");
  bellShape.setAttribute(
    "d",
    "M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"
  );

  const slash = document.createElementNS(svgNamespace, "path");
  slash.setAttribute("d", "M4 4l16 16");
  slash.setAttribute("class", "slash");

  bell.append(bellShape, slash);
  notificationStatus.appendChild(bell);

  panel.append(timer, notificationStatus);
  shadow.append(style, panel);
  document.documentElement.appendChild(host);
  timerOverlayHost = host;

  const savedPosition = (await chrome.storage.local.get([TIMER_POSITION_KEY]))[
    TIMER_POSITION_KEY
  ];
  if (
    Number.isFinite(savedPosition?.left) &&
    Number.isFinite(savedPosition?.top)
  ) {
    const maxLeft = Math.max(8, window.innerWidth - panel.offsetWidth - 8);
    const maxTop = Math.max(8, window.innerHeight - panel.offsetHeight - 8);
    panel.style.right = "auto";
    panel.style.left = `${Math.min(maxLeft, Math.max(8, savedPosition.left))}px`;
    panel.style.top = `${Math.min(maxTop, Math.max(8, savedPosition.top))}px`;
  }

  enableTimerOverlayDragging(panel, panel);
  await refreshTimerOverlayData();
  timerOverlayHandle = setInterval(renderTimerOverlay, 1000);
}

function hideTimerOverlay() {
  if (timerOverlayHandle) {
    clearInterval(timerOverlayHandle);
    timerOverlayHandle = null;
  }
  timerOverlayHost?.remove();
  timerOverlayHost = null;
}

async function setTimerOverlayVisible(visible) {
  await chrome.storage.local.set({ [TIMER_VISIBLE_KEY]: visible });
  if (visible) {
    await showTimerOverlay();
  } else {
    hideTimerOverlay();
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "submitTracker:togglePageTimer") {
    setTimerOverlayVisible(!timerOverlayHost)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes[HEARTBEAT_CLOCK_KEY]) {
    heartbeatClock = changes[HEARTBEAT_CLOCK_KEY].newValue || null;
    renderTimerOverlay();
  }
  if (areaName === "local" && changes[TIMER_VISIBLE_KEY]) {
    if (changes[TIMER_VISIBLE_KEY].newValue) {
      showTimerOverlay();
    } else {
      hideTimerOverlay();
    }
  }

  if (areaName === "sync" && changes.chimeSettings) {
    timerOverlayChimeEnabled = Boolean(
      changes.chimeSettings.newValue?.enabled
    );
    timerOverlayChimeDelaySeconds =
      Number(changes.chimeSettings.newValue?.delaySeconds) || 300;
    timerOverlayChimeSound = changes.chimeSettings.newValue?.sound || "gentle";
    renderTimerOverlay();
    renderNotificationStatusIcon();
  }
});

chrome.storage.local.get([TIMER_VISIBLE_KEY]).then((result) => {
  if (result[TIMER_VISIBLE_KEY]) showTimerOverlay();
});
