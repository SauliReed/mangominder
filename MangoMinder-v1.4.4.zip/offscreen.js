// Short-lived offscreen audio page. Chime timing is handled by chrome.alarms
// in the service worker so this document only exists when sound is needed.

function playChime(sound = "gentle") {
  const AudioContextClass = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!AudioContextClass) return;

  const context = new AudioContextClass();
  const start = context.currentTime;

  const presets = {
    gentle: {
      tones: [
        { frequency: 659.25, offset: 0, duration: 0.75 },
        { frequency: 783.99, offset: 0.12, duration: 0.63 }
      ],
      volume: 0.18,
      wave: "sine"
    },
    clear: {
      tones: [
        { frequency: 783.99, offset: 0, duration: 0.42 },
        { frequency: 1046.5, offset: 0.18, duration: 0.62 }
      ],
      volume: 0.28,
      wave: "triangle"
    },
    strong: {
      tones: [
        { frequency: 659.25, offset: 0, duration: 0.38 },
        { frequency: 987.77, offset: 0.16, duration: 0.5 },
        { frequency: 659.25, offset: 0.82, duration: 0.38 },
        { frequency: 987.77, offset: 0.98, duration: 0.65 }
      ],
      volume: 0.42,
      wave: "square"
    }
  };

  const preset = presets[sound] || presets.gentle;
  let finishAt = 0;

  preset.tones.forEach(({ frequency, offset, duration }) => {
    const gain = context.createGain();
    const oscillator = context.createOscillator();
    const toneStart = start + offset;
    const toneEnd = toneStart + duration;

    oscillator.type = preset.wave;
    oscillator.frequency.value = frequency;
    oscillator.connect(gain);
    gain.connect(context.destination);
    gain.gain.setValueAtTime(0.0001, toneStart);
    gain.gain.exponentialRampToValueAtTime(preset.volume, toneStart + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, toneEnd);
    oscillator.start(toneStart);
    oscillator.stop(toneEnd);
    finishAt = Math.max(finishAt, offset + duration);
  });

  setTimeout(() => context.close(), (finishAt + 0.25) * 1000);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "submitTracker:playChime") playChime(msg.sound);
});
