(() => {
  const HEARTBEAT_CHANNEL = "submitTracker:heartbeatClock";
  const heartbeatPath = "/api/task-time-tracking/heartbeat";
  const acquisitionPath = "/api/omni-elo";
  const nativeFetch = window.fetch;
  const nativeOpen = XMLHttpRequest.prototype.open;
  const nativeSend = XMLHttpRequest.prototype.send;
  const xhrRequests = new WeakMap();

  function isHeartbeat(url) {
    try {
      const parsed = new URL(url, location.href);
      return parsed.origin === location.origin && parsed.pathname === heartbeatPath;
    }
    catch { return false; }
  }

  function isAcquisition(url, method) {
    try {
      const parsed = new URL(url, location.href);
      return parsed.origin === location.origin && parsed.pathname === acquisitionPath &&
        String(method || "GET").toUpperCase() === "GET";
    }
    catch { return false; }
  }

  function reportAcquisition(response, status) {
    if (status < 200 || status >= 300 || !response ||
        !Number.isInteger(response.runConfigId) ||
        !Number.isInteger(response.promptId) ||
        !Number.isInteger(response.generationA?.id) ||
        !Number.isInteger(response.generationB?.id)) return;
    const itemKey = [response.runConfigId, response.promptId,
      response.generationA.id, response.generationB.id].join(":");
    window.postMessage({ channel: HEARTBEAT_CHANNEL, type: "acquired",
      itemKey, observedAt: Date.now() }, location.origin);
  }

  function parseBody(body) {
    try { return typeof body === "string" ? JSON.parse(body) : null; }
    catch { return null; }
  }

  function reportHeartbeat(request, response, status) {
    if (status < 200 || status >= 300 || response?.success !== true ||
        typeof request?.taskId !== "string" || !request.taskId ||
        !Number.isFinite(request.intervalSeconds) || request.intervalSeconds < 0) return;
    const rawLimit = response.limitStatus?.effectiveLimits?.maxTimePerItem;
    window.postMessage({
      channel: HEARTBEAT_CHANNEL,
      type: "success",
      taskId: request.taskId,
      limit: Number.isFinite(rawLimit) && rawLimit > 0 ? rawLimit : null,
      observedAt: Date.now()
    }, location.origin);
  }

  window.fetch = function(input, init) {
    let url, body, method;
    try {
      url = typeof input === "string" || input instanceof URL ? input : input.url;
      method = init?.method || (input instanceof Request ? input.method : "GET");
      if (isHeartbeat(url)) {
        body = init?.body;
        if (body === undefined && input instanceof Request) body = input.clone().text();
      }
    } catch {}
    const result = nativeFetch.apply(this, arguments);
    if (isHeartbeat(url)) {
      Promise.resolve(body).then(parseBody).then(request => {
        if (!request) return;
        result.then(res => res.clone().json()
          .then(data => reportHeartbeat(request, data, res.status)).catch(() => {})).catch(() => {});
      }).catch(() => {});
    }
    if (isAcquisition(url, method)) {
      result.then(res => res.clone().json()
        .then(data => reportAcquisition(data, res.status)).catch(() => {})).catch(() => {});
    }
    return result;
  };

  XMLHttpRequest.prototype.open = function(method, url) {
    xhrRequests.set(this, { method, url });
    return nativeOpen.apply(this, arguments);
  };
  function readXHRResponse(xhr) {
    return xhr.responseType === "json" ? xhr.response : JSON.parse(xhr.responseText);
  }
  XMLHttpRequest.prototype.send = function(body) {
    const requestInfo = xhrRequests.get(this);
    if (isHeartbeat(requestInfo?.url)) {
      const request = parseBody(body);
      this.addEventListener("load", () => {
        try { reportHeartbeat(request, readXHRResponse(this), this.status); }
        catch {}
      }, { once: true });
    }
    if (isAcquisition(requestInfo?.url, requestInfo?.method)) {
      this.addEventListener("load", () => {
        try { reportAcquisition(readXHRResponse(this), this.status); }
        catch {}
      }, { once: true });
    }
    return nativeSend.apply(this, arguments);
  };
})();
