const DEFAULT_LABELS = ["Submit"];

function normalizeLabel(s) {
  return (s || "").trim().replace(/\s+/g, " ").toLowerCase();
}

function formatDuration(ms) {
  if (!Number.isFinite(ms) || ms < 0) return "—";
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;

  const parts = [];
  if (h) parts.push(`${h}h`);
  if (m || h) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(" ");
}

function formatTaskLimit(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0) return "—";
  const minutes = Math.floor(seconds / 60);
  const remainder = Math.floor(seconds % 60);
  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

async function getActiveTabOrigin() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return null;
  try {
    return new URL(tab.url).origin;
  } catch {
    return null;
  }
}

async function loadSiteData(origin) {
  const key = `site:${origin}`;
  const obj = await chrome.storage.local.get([key]);
  return { key, data: obj[key] || { count: 0, lastPressedAt: null } };
}

async function getLabels() {
  const { trackedLabels } = await chrome.storage.sync.get(["trackedLabels"]);
  return Array.isArray(trackedLabels) && trackedLabels.length
    ? trackedLabels
    : DEFAULT_LABELS;
}

async function setLabels(labels) {
  await chrome.storage.sync.set({ trackedLabels: labels });
}

function renderLabels(labels) {
  const ul = document.getElementById("labels");
  ul.innerHTML = "";

  labels.forEach((lbl) => {
    const li = document.createElement("li");
    li.textContent = lbl;

    const btn = document.createElement("button");
    btn.textContent = "Remove";
    btn.className = "remove";
    btn.addEventListener("click", async () => {
      const next = labels.filter((x) => normalizeLabel(x) !== normalizeLabel(lbl));
      await setLabels(next.length ? next : DEFAULT_LABELS);
      init(); // refresh
    });

    li.appendChild(btn);
    ul.appendChild(li);
  });
}

let timerHandle = null;

async function init() {
  if (timerHandle) clearInterval(timerHandle);

  const siteEl = document.getElementById("site");
  const countEl = document.getElementById("count");
  const sinceEl = document.getElementById("since");

  const origin = await getActiveTabOrigin();
  siteEl.textContent = origin || "—";

  if (!origin) {
    countEl.textContent = "0";
    sinceEl.textContent = "—";
    return;
  }

  const { key, data } = await loadSiteData(origin);
  countEl.textContent = String(data.count || 0);

  let clock = (await chrome.storage.local.get(`heartbeatClock:${origin}`))[`heartbeatClock:${origin}`];
  let zeroRoute = false;
  const refreshRoute = async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    try {
      const url = new URL(tab?.url);
      zeroRoute = url.hostname === "www.multimango.com" &&
        ["/tasks", "/qa-feedback"].includes(url.pathname.replace(/\/$/, ""));
    } catch { zeroRoute = false; }
  };
  await refreshRoute();
  const limitEl = document.getElementById("taskLimit");
  const tick = () => {
    sinceEl.textContent = zeroRoute ? "0s" : Number.isFinite(clock?.firstHeartbeatAt)
      ? formatDuration(Math.max(0, Date.now() - clock.firstHeartbeatAt))
      : clock?.waitingAtZero ? "0s" : "—";
    limitEl.textContent = zeroRoute ? "—" : formatTaskLimit(clock?.limit);
  };
  tick();
  timerHandle = setInterval(async () => {
    await refreshRoute();
    const obj = await chrome.storage.local.get([key, `heartbeatClock:${origin}`]);
    countEl.textContent = String(obj[key]?.count || 0);
    clock = obj[`heartbeatClock:${origin}`];
    tick();
  }, 1000);

  // Labels UI
  const labels = await getLabels();
  renderLabels(labels);

  // Reset button
  document.getElementById("reset").onclick = async () => {
    await chrome.storage.local.set({
      [key]: { count: 0, lastPressedAt: null }
    });
    init();
  };

  // Toggle the floating timer inside the active supported webpage.
  document.getElementById("pageTimer").onclick = async () => {
    const button = document.getElementById("pageTimer");
    const status = document.getElementById("pageTimerStatus");
    button.disabled = true;
    status.textContent = "";

    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });
      if (!Number.isInteger(tab?.id)) throw new Error("No active tab");

      // Await delivery before closing this popup. This also detects supported
      // pages that need one refresh after installing or reloading the extension.
      const response = await chrome.tabs.sendMessage(tab.id, {
        type: "submitTracker:togglePageTimer"
      });
      if (!response?.ok) throw new Error("Timer overlay was not toggled");
      window.close();
    } catch {
      status.textContent =
        "Refresh this supported page once, then try again.";
      button.disabled = false;
    }
  };

  // Add label
  document.getElementById("addLabel").onclick = async () => {
    const input = document.getElementById("newLabel");
    const raw = (input.value || "").trim();
    if (!raw) return;

    const existing = await getLabels();
    const nRaw = normalizeLabel(raw);
    const deduped = [
      ...existing.filter((x) => normalizeLabel(x) !== nRaw),
      raw
    ];

    await setLabels(deduped);
    input.value = "";
    init();
  };

  document.getElementById("newLabel").onkeydown = (e) => {
    if (e.key === "Enter") document.getElementById("addLabel").click();
  };
}

init();

// Chime controls are initialized independently from the existing popup workflow.
const DEFAULT_CHIME_SETTINGS = { enabled: false, delaySeconds: 300, sound: "gentle" };

function boundedNumber(id, min, max) {
  const value = Number.parseInt(document.getElementById(id).value, 10);
  return Math.min(max, Math.max(min, Number.isFinite(value) ? value : 0));
}

async function initChimeControls() {
  const { chimeSettings } = await chrome.storage.sync.get(["chimeSettings"]);
  const settings = { ...DEFAULT_CHIME_SETTINGS, ...chimeSettings };
  const total = Math.max(1, Number(settings.delaySeconds) || 300);

  document.getElementById("chimeEnabled").checked = Boolean(settings.enabled);
  document.getElementById("chimeMinutes").value = String(Math.floor(total / 60));
  document.getElementById("chimeSeconds").value = String(total % 60);
  document.getElementById("chimeSound").value = ["silent", "gentle", "clear", "strong"].includes(settings.sound)
    ? settings.sound
    : "gentle";

  document.getElementById("saveChime").onclick = async () => {
    const minutes = boundedNumber("chimeMinutes", 0, 5999);
    const seconds = boundedNumber("chimeSeconds", 0, 59);
    const delaySeconds = minutes * 60 + seconds;
    const status = document.getElementById("chimeStatus");

    if (delaySeconds < 30) {
      status.textContent = "Choose a delay of at least 30 seconds.";
      return;
    }

    await chrome.storage.sync.set({
      chimeSettings: {
        enabled: document.getElementById("chimeEnabled").checked,
        delaySeconds,
        sound: document.getElementById("chimeSound").value
      }
    });
    chrome.runtime.sendMessage({ type: "submitTracker:chimeSettingsChanged" });
    status.textContent = "Notification settings saved.";
  };

  document.getElementById("testChime").onclick = () => {
    chrome.runtime.sendMessage({
      type: "submitTracker:previewChime",
      sound: document.getElementById("chimeSound").value
    });
  };
}

initChimeControls();

async function initThemeControl() {
  const toggle = document.getElementById("darkMode");
  const status = document.getElementById("themeStatus");
  const origin = await getActiveTabOrigin();
  if (!origin || !/^https:\/\/(?:[\w-]+\.)*(?:multimango|parimango)\.com$/.test(origin)) {
    toggle.disabled = true;
    status.textContent = "Available on supported Mango sites.";
    return;
  }
  const key = `pageTheme:${origin}`;
  const saved = await chrome.storage.local.get(key);
  toggle.checked = saved[key] === "dark";
  toggle.addEventListener("change", async () => {
    toggle.disabled = true;
    try {
      await chrome.storage.local.set({ [key]: toggle.checked ? "dark" : "light" });
      status.textContent = "Saved for this site.";
    } catch {
      toggle.checked = !toggle.checked;
      status.textContent = "Could not save the theme choice.";
    } finally {
      toggle.disabled = false;
    }
  });
}
initThemeControl();
