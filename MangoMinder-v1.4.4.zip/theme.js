(() => {
  const key = `pageTheme:${location.origin}`;
  let preference = null;
  let rootObserver = null;

  function applyTheme() {
    const root = document.documentElement;
    if (!root || preference === null) return;
    const dark = preference === "dark";
    if (root.classList.contains(dark ? "light" : "dark")) {
      root.classList.remove(dark ? "light" : "dark");
    }
    if (!root.classList.contains(dark ? "dark" : "light")) {
      root.classList.add(dark ? "dark" : "light");
    }
    const scheme = dark ? "dark" : "light";
    if (root.style.colorScheme !== scheme) root.style.colorScheme = scheme;
  }

  function watchRoot() {
    if (!document.documentElement || rootObserver) return;
    rootObserver = new MutationObserver(applyTheme);
    rootObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class", "style"]
    });
    applyTheme();
  }

  watchRoot();
  if (!rootObserver) {
    const documentObserver = new MutationObserver(() => {
      watchRoot();
      if (rootObserver) documentObserver.disconnect();
    });
    documentObserver.observe(document, { childList: true, subtree: true });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[key]) return;
    preference = changes[key].newValue === "dark" ? "dark" :
      changes[key].newValue === "light" ? "light" : null;
    applyTheme();
  });
  chrome.storage.local.get(key).then(result => {
    preference = result[key] === "dark" ? "dark" :
      result[key] === "light" ? "light" : null;
    applyTheme();
  });
})();
